Here are instructions for the files in the subfolders. Start by unzipping the folders.

conference building/

-The folder "hiddengenes/" includes data from running the hidden genes genetic algorithm on the evacuation of the conference building. 

-The folder "deterministic/" includes data from the ad-hoc attempt to find the deterministic equivalent problem solution with the hidden genes GA. The original (stochastic) problem solution is included in the initial population to assure faster convergence. The population includes 300 individuals instead of 40 individuals, that is used for the stochastic problem. Mutation probability was first set to 0.40, but in later iterations it was set to 0.1, as we realized that only small changes are needed to find the deterministic optimum. The deterministic optimum is found in the 70th iteration (when indexing starts from 0).

-The python script "convergence_broken_axis.py" creates the convergence plot.

-The text file "realizations_totalevactime_optimalguided_conference.txt" includes the total evacuation times for the 30 different realizations of the optimal guided evacuation given by the hidden gene genetic algorithm.

-The text file "realizations_totalevactime_unguided_conference.txt" includes the total evacuation times for the 30 different realizations of the unguided evacuation.

-The text file "realizations_totalevactime_optimalguided_deterministic_conference.txt" includes the total evacuation times for the 30 different realizations of the optimal guided evacuation of the deterministic equivalent problem, also solved with the hidden genes genetic algorithm.

-The python script "kernel_density_comparison.py" plots the histograms and kernel density estimates for the total evacuation times for the optimal guided evacuation and unguided evacuation based on 30 samples.


hexagon-shaped area/

-The folder "hiddengenes/" includes data from running the hidden genes genetic algorithm on the evacuation of the hexagon shaped area.

-The folders "1guide/", "2guide/", "3guide/", "4guide/" includes data from running the genetic algorithm on the evacuation of the hexagon shaped area with a fixed amount of guides.

-The python script "barchart.py" plots the mean total evacuation times for the fixed amount of guides.

-The python script "convergence_hexagon.py" creates the convergence plot.

-The python script "kernel_density_comparison.py" plots the histograms and kernel density estimates for the total evacuation times for the optimal guided evacuations and unguided evacuation based on 30 samples.
