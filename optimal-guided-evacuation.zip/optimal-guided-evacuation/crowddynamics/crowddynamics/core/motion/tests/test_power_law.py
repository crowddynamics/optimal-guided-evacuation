import pytest


@pytest.mark.skip('Write more tests!')
def test_interactions():
    pass
