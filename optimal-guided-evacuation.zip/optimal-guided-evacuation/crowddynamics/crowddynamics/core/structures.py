"""Structure numpy.dtypes"""
import numpy as np


# TODO: replace
obstacle_type_linear = np.dtype([
    ('p0', np.float64, 2),
    ('p1', np.float64, 2),
])
