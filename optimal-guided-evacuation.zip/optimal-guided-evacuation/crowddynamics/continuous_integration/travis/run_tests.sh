#!/bin/bash

# Run tests
py.test
