Interactions
------------

.. automodule:: crowddynamics.core.interactions
   :noindex:
