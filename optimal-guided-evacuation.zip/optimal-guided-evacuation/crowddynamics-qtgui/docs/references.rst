References

.. [campagnola2012] Campagnola, L. (2014). PyQtGraph - Scientific Graphics and GUI Library for Python. Posledn{’\i} Aktualizace. Retrieved from http://www.pyqtgraph.org/
.. [Hess2013] Hess, D., & Summerfield, M. (2013). PyQt Whitepaper.
.. [Sepulveda2014] Sepúlveda, S., Reyes, P., & Weinstein, A. (2014). Visualizing physiological signals in real-time. PROC. OF THE 14th PYTHON IN SCIENCE CONF. Retrieved from https://github.com/ssepulveda/RTGraph
