Crowddynamics Qt Gui
====================
Graphical user interface for running crowddynamics_ simulations.

.. _crowddynamics: https://github.com/jaantollander/CrowdDynamics
