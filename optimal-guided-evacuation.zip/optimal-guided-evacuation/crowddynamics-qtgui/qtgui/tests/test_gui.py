"""
Gui tests

https://github.com/asweigart/pyautogui
"""


def test_gui():
    assert True
